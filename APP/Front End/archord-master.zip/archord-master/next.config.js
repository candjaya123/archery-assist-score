const withImages = require("next-images");
const withBundleAnalyzer = require("@next/bundle-analyzer")({
	enabled: process.env.ANALYZE === "true",
});

const withPWA = require("next-pwa")({
	dest: "public",
	register: true,
	skipWaiting: true,
  disable: process.env.NODE_ENV === "development",
});

module.exports = withPWA(
  {
    ...withImages(
      withBundleAnalyzer({
        images: {
          disableStaticImages: true,
        },
      })
    ),
    env: {
      NEXT_PUBLIC_BASE_URL: process.env.NEXT_PUBLIC_BASE_URL,
    },
    reactStrictMode: true,
    swcMinify: true,
  }
);
