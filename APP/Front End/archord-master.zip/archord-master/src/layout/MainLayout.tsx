import { Layout, message } from "antd";
import ArcheryTarget from "./partials/ArcheryTarget";
const { Content } = Layout;

interface LayoutProps {
	children: React.ReactNode;
}

function MainLayout({ children }: LayoutProps): JSX.Element {
	return (
		<main>
			<header className="h-14 bg-emerald-600 w-full flex flex-row items-center px-2 z-50 absolute">
				<h1 className="text-white text-2xl font-bold">Archery Recorder</h1>
			</header>
			<div className="flex flex-row w-full absolute inset-0 h-screen bg-gray-500 pt-14">
				<ArcheryTarget />
				<div className="flex-3 h-full bg-emerald-300">
					{children}
				</div>
			</div>
		</main>
	);
}

export default MainLayout;
