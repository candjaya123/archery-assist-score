/* eslint-disable @next/next/no-img-element */
import React, { useEffect, useState } from "react";
import socketIOClient from "socket.io-client";

function ArcheryTarget() {
	const [img, setImg] = useState("");
	const socketInit = async () => {
		const socket = socketIOClient("ws://localhost:8888");
		socket.on("img", (event: any) => {
			setImg(event.filename)
		});
	};

	useEffect(() => {
		socketInit();
	}, []);

	return (
		<div className="flex-2 flex items-center justify-center">
			{img.length ? (
				<img
					src={`http://localhost:8888/static/${img}`}
					alt="ini"
					className="w-full"
				/>
			) : `Post the image`}
			{/* <div className="target">
				<div className="white-outer rounded-full"> </div>
				<div className="white-inner rounded-full"></div>
				<div className="black-outer rounded-full"></div>
				<div className="black-inner rounded-full"></div>
				<div className="blue-outer rounded-full"></div>
				<div className="blue-inner rounded-full"></div>
				<div className="red-outer rounded-full"></div>
				<div className="red-inner rounded-full"></div>
				<div className="gold-outer rounded-full"></div>
				<div className="gold-inner rounded-full">
					<div className="cross"></div>
				</div>
			</div> */}
		</div>
	);
}

export default ArcheryTarget;
