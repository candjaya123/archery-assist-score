import { Image } from "antd";
import React, { useEffect } from "react";
import LOGO from "../../assets/logo.png";
import Router from "next/router";

function Loading({}) {
	useEffect(() => {
		setTimeout(() => {
			Router.replace("/home");
		}, 3000);
	}, []);
	return (
		<main className="h-screen w-screen bg-green-600 flex flex-col items-center justify-center">
			<div className="flex-row flex items-center">
				<Image
					src={LOGO}
					alt="logo-archord"
					preview={false}
					width={200}
					height={200}
				/>
				<h1 className="text-4xl font-bold text-white">Archery Recorder</h1>
			</div>

			<p className="animate-pulse mt-24 text-white">Loading...</p>
		</main>
	);
}

export default Loading;
