import React, { useState } from "react";
import Database from "./partials/Database";
import Help from "./partials/Help";
import Score from "./partials/Score";

function Home({}) {
	const [tabState, setTabState] = useState("score");
	return (
		<div className="w-full h-96">
			<nav className="w-full bg-emerald-300 px-4 pt-1">
				<div className="flex flex-row gap-4">
					<button
						onClick={() => setTabState("score")}
						className={`text-xl p-4 bg-white rounded-t-xl text-green-700 ${
							tabState !== "score" ? "bg-opacity-20" : null
						}`}
					>
						Score
					</button>
					<button
						onClick={() => setTabState("database")}
						className={`text-xl p-4 bg-white rounded-t-xl text-green-700 ${
							tabState !== "database" ? "bg-opacity-20" : null
						}`}
					>
						Database
					</button>
					<button
						onClick={() => setTabState("help")}
						className={`text-xl p-4 bg-white rounded-t-xl text-green-700 ${
							tabState !== "help" ? "bg-opacity-20" : null
						}`}
					>
						Help
					</button>
				</div>
			</nav>
			<div className="w-full">
        {
          (() => {
            switch (tabState) {
              case "score":
                return <Score />
              case "database":
                return <Database />
              case "help":
                return <Help />
              default:
                return <p className="capitalize">error</p>
            }
          })()
        }
			</div>
		</div>
	);
}

export default Home;
