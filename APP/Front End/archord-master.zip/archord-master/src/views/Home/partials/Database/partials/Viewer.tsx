/* eslint-disable react-hooks/exhaustive-deps */
import { Table } from "antd";
import React, { useEffect, useState } from "react";

function Viewer({ viewerShow, setViewerShow, data, id }: any) {
	const [selectedData, setSelectedData] = useState<any>({});
	const [_data, _setData] = useState([]);
	const [columns, setColumns] = useState<any>([
		{
			title: "Session",
			width: 100,
			dataIndex: "session",
			key: "session",
			fixed: "left",
		},
	]);

	const getShowData = async (params: any) => {
		let widths: any = [];

		let _data: any = [];
		params?.forEach((e: any, i: any) => {
			let n: any = 0;
			let shoots: any = {};
			for (let index = 0; index < e?.data.length; index++) {
				shoots = {
					...shoots,
					[`shoot${index + 1}`]: e?.data[index]?.score,
				};
			}

			console.log(shoots);

			_data.push({
				...e,
				no: i,
				key: i,
				session: "Session " + (i + 1),
				...shoots,
			});

			e?.data?.forEach((key: any) => {
				n = n + 1;
			});
			widths.push(parseInt(n));
		});

		_setData(_data);

		let createColumns = [];

		for (let i = 1; i <= Math.max(...widths); i++) {
			createColumns.push({
				title: "Shoot " + i,
				dataIndex: "shoot" + i,
				key: i,
			});
		}

		setColumns([
			{
				title: "Session",
				width: 100,
				dataIndex: "session",
				key: "session",
				fixed: "left",
			},
		]);
		setColumns([
			{
				title: "Session",
				width: 100,
				dataIndex: "session",
				key: "session",
				fixed: "left",
			},
			...createColumns,
		]);
	};

	useEffect(() => {
		data?.forEach((e: any) => {
			if (e?._id == id) {
				setSelectedData(e);
				getShowData(e?.data);
			}
		});
	}, [id, viewerShow]);
	return (
		<div
			className={`absolute flex items-center justify-center inset-0 bg-blue-400 bg-opacity-60 w-screen h-screen ${
				viewerShow ? "" : "hidden"
			}`}
		>
			<div className="w-11/12 bg-white z-50 p-4">
				<div className="w-full">
					<p className="text-2xl font-semibold text-blue-500">
						Athlete Name : {selectedData?.athlete}
					</p>
					<p className="text-2xl font-semibold text-blue-500">
						Time Recording : {selectedData?.lastUpdate}
					</p>
				</div>
				<Table
					pagination={{ pageSize: 5 }}
					columns={columns}
					dataSource={_data}
					scroll={{ x: 800, y: 325 }}
					className="w-11/12"
				/>
				<div className="w-full flex justify-end">
					<button className="w-24 text-white py-2 text-2xl bg-red-400" onClick={() => setViewerShow(!viewerShow)}>
						Close
					</button>
				</div>
			</div>
		</div>
	);
}

export default Viewer;
