import { Space, Table, Tag } from "antd";
import { ColumnsType } from "antd/lib/table";
import React, { useEffect, useState } from "react";
import { DataService } from "../../../../services/Data";
import Viewer from "./partials/Viewer";

function Database({}) {
	const [data, setData] = useState([]);
	const [viewerShow, setViewerShow] = useState(false);
	const [inDelete, setInDelete] = useState(false);
	const [ID, setID] = useState("");

	const deleteData = async (id: string) => {
    setID(id);
    setInDelete(true)
		DataService.removeData(id)
    .then(() => {
				getData();
			})
			.catch((ex: any) => {
				console.log(ex.message);
			})
      .finally(() => {
        setInDelete(false)
      })
	};

	const columns: ColumnsType<any> = [
		{
			title: "Name",
			dataIndex: "athlete",
			key: "athlete",
			render: (text) => <a>{text}</a>,
		},
		{
			title: "Time",
			dataIndex: "lastUpdate",
			key: "lastUpdate",
		},
		{
			title: "Action",
			render: (el: any) => (
				<Space size="middle">
					<button
						className="w-24 py-2 bg-yellow-500 text-white"
						onClick={() => {
							setID(el._id);
							setViewerShow(true);
						}}
					>
						Open
					</button>
					<button
						className="w-24 py-2 bg-red-500 text-white"
						onClick={() => deleteData(el._id)}
					>
						{
              ((el._id === ID) && (inDelete)) ? "Deleting..." : "Delete"
            }
					</button>
				</Space>
			),
		},
	];

	const getData = async () => {
		const res = await DataService.getData();
		setData(
			res?.map((e: any, i: number) => {
				return {
					...e,
					lastUpdate: new Date(e?.lastUpdate).toLocaleString(),
				};
			})
		);
	};
	useEffect(() => {
		getData();
	}, []);
	return (
		<div className="px-4 bg-emerald-300 w-full pb-4">
			<div className="bg-white p-4 w-full flex flex-col">
				<Table
					columns={columns}
					dataSource={data}
					pagination={{ pageSize: 5 }}
				/>
				<Viewer
					data={data}
					id={ID}
					viewerShow={viewerShow}
					setViewerShow={setViewerShow}
				/>
			</div>
		</div>
	);
}

export default Database;
