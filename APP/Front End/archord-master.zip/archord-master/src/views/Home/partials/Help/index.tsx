import React from "react";
import FAQ from "./FAQ.json";
function Help({}) {
	return (
		<div className="px-4 bg-emerald-300 w-full pb-4">
			<div className="bg-white p-4 w-full flex flex-col">
				<h1 className="text-2xl font-bold text-emerald-400">
					Frequently Asked
				</h1>
				<div className="h-96 overflow-auto">
					{FAQ.map((e: any, i: number) => {
						return (
							<div key={i} className="mb-4">
								<h2 className="text-2xl">{e.title}</h2>
								<p>{e.description}</p>
								<ol type="a">
									{e.list.map((lst: any, index: number) => {
										return (
											<li className="mb-2" key={index}>
												{index + 1}. {lst}
											</li>
										);
									})}
								</ol>
							</div>
						);
					})}
				</div>
			</div>
		</div>
	);
}

export default Help;
