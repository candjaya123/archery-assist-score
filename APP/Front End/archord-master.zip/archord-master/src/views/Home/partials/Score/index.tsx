/* eslint-disable react-hooks/exhaustive-deps */
import { DatePicker, DatePickerProps, message, Space, Table } from "antd";
import { ColumnsType } from "antd/lib/table";
import React, { useEffect, useRef, useState } from "react";
import { DataService } from "../../../../services/Data";
import socketIOClient from "socket.io-client";
import { OnLogService } from "../../../../services/OnLog";
import useSound from "use-sound";
import soundStrings from "./static/sound.json";

function Score() {
	const [columns, setColumns] = useState<any>([
		{
			title: "Session",
			width: 100,
			dataIndex: "session",
			key: "session",
			fixed: "left",
		},
	]);
	const [data, setData] = useState<any>([]);
	const [isMoving, setMoving] = useState(false);
	const [isSaving, setSaving] = useState(false);
	const [isDeleteAll, setDeleteAll] = useState(false);
	const [isDeleteLast, setDeleteLast] = useState(false);
	const [athlete, setAthlete] = useState("");
	const [stringSound, setStringSound] = useState("/sound/satu.mp3");
	const [play] = useSound(stringSound);

	const getShowData = async (cred: any) => {
		const result = cred?.data;
		const lastData = cred?.lastData;
		let widths: any = [];

		let _data: any = [];

		if (!result.length) {
			_data.push({
				no: 0,
				key: 0,
				session: "Session 1`",
			});
		}

		result?.forEach((e: any, i: any) => {
			let n: any = 0;

			_data.push({
				...e,
				no: i,
				key: i,
				session: "Session " + (i + 1),
			});
			Object.keys(e).forEach((key: any) => {
				n = n + 1;
			});
			widths.push(parseInt(n));
		});

		setData(_data);

		let createColumns = [];

		for (let i = 1; i <= Math.max(...widths); i++) {
			createColumns.push({
				title: "Shoot " + i,
				dataIndex: "shoot" + i,
				key: i,
			});
		}

		setColumns([
			{
				title: "Session",
				width: 100,
				dataIndex: "session",
				key: "session",
				fixed: "left",
			},
		]);
		setColumns([...columns, ...createColumns]);

		if (!lastData) return;

		soundStrings.forEach((sound: any, i: number) => {
			if (sound?.value == lastData) {
				setStringSound(sound?.sound);
			}
		});

		setTimeout(() => {
			const buttonPlay = document.getElementById("button-play");
			buttonPlay?.click();
		}, 2000);

		// buttonPlay.current.click()
	};

	const socketInit = async () => {
		const socket = socketIOClient("ws://localhost:8888");
		socket.on("archord", (event: any) => {
			getShowData(event);
		});
	};

	const getData = async () => {
		const result = await DataService.getShowData();
		getShowData(result);
	};

	const deleteAll = async () => {
		setDeleteAll(true);
		const result = await OnLogService.deleteAll();
		if (result?.data) return setDeleteAll(false);
		message.success({
			content: "Delete last session is success",
		});
		setDeleteAll(false);
	};

	const deleteLast = async () => {
		setDeleteLast(true);
		const result = await OnLogService.deleteLast();
		if (result?.data) return setDeleteLast(false);
		message.success({
			content: "Delete last shoot is success",
		});
		setDeleteLast(false);
	};

	const saveOnlog = async () => {
		setMoving(true);
		const result = await OnLogService.save();
		if (!result?.data) return setMoving(false);
		setMoving(false);
		message.success({
			content: "Create new session is success",
		});
	};

	const saveData = async () => {
		if (!athlete)
			return message.error({
				content: "You have to input athlete's name",
			});
		setSaving(true);
		const result = await DataService.saveData({
			athlete,
		});
		if (result?.data) {
			getData();
			message.success({
				content: "Save data is success",
			});
			return setSaving(false);
		}
		setSaving(false);
	};

	useEffect(() => {
		getData();
		socketInit();
	}, []);

	return (
		<div className="px-4 bg-emerald-300 w-full">
			<div className="bg-white w-full flex flex-col p-8">
				<form className="w-full mt-4 px-4">
					<div className="flex flex-row gap-4 w-full">
						<label
							className="text-green-500 text-lg flex-2"
							htmlFor="archer-name"
						>
							Nama Atlet
						</label>
						<input
							className="border-2 border-green-400 flex-6 px-2 text-green-600"
							type="text"
							id="archer-name"
							onChange={(e) => setAthlete(e.target.value)}
						/>
					</div>
				</form>
				<div className="w-full items-center justify-center flex mt-8">
					<Table
						columns={columns}
						dataSource={data}
						scroll={{ x: 800, y: 300 }}
						className="w-11/12"
					/>
				</div>
				<div className="flex flex-row justify-between">
					<div>
						<button
							className="mt-4 bg-yellow-500 py-2 w-24 rounded-xl text-white"
							id="button-play"
							onClick={() => play()}
							// ref={buttonPlay}
						>
							Calibrate Sound
						</button>
					</div>
					<div className="flex flex-row justify-end gap-4 mt-4">
						<button
							className="bg-yellow-500 py-2 w-24 rounded-xl text-white"
							onClick={deleteLast}
						>
							{isDeleteLast ? "Loading..." : "Delete Last Shoot"}
						</button>
						<button
							className="bg-orange-500 py-2 w-24 rounded-xl text-white"
							onClick={deleteAll}
						>
							{isDeleteAll ? "Loading..." : "Reset Current Session"}
						</button>
						<button
							className="bg-red-500 py-2 w-24 rounded-xl text-white"
							onClick={saveOnlog}
						>
							{isMoving ? "Loading..." : "Next Session"}
						</button>
						<button
							className="bg-emerald-500 py-2 w-24 rounded-xl text-white"
							onClick={saveData}
						>
							{isSaving ? "Loading..." : "Save"}
						</button>
					</div>
				</div>
			</div>
		</div>
	);
}

export default Score;
