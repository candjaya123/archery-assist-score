import MainApi from "./AxiosInstance";

class service {
	async getData() {
		const data = await MainApi.get("/data");
		return data.data;
	}
	async removeData(id: string) {
		const data = await MainApi.delete("/data/" + id);
		return data.data;
	}
	async getShowData() {
		const data = await MainApi.get("/data/show");
		return data.data;
	}
	async saveData(params: any) {
		const data = await MainApi.post("/data/save", params);
		return data.data;
	}
}

export const DataService = new service();
