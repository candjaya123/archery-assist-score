import MainApi from "./AxiosInstance";

class service {
	async save() {
		const data = await MainApi.get("/onlog/save");
		return data.data;
	}
	async deleteAll() {
		const data = await MainApi.delete("/onlog/");
		return data.data;
	}
	async deleteLast() {
		const data = await MainApi.delete("/onlog/last");
		return data.data;
	}
}

export const OnLogService = new service();
