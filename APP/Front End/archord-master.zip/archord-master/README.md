# Archord Front-End Code Description

>Archord
│   .env
│   .eslintrc.json
│   .gitignore
│   next-env.d.ts
│   next.config.js
│   package.json
│   postcss.config.js
│   README.md
│   tailwind.config.js
│   tsconfig.json
│   yarn.lock
│
├───public
│   │   favicon.ico
│   │   icon-192x192.png
│   │   icon-256x256.png
│   │   icon-384x384.png
│   │   icon-512x512.png
│   │   manifest.json
│   │   sw.js
│   │   sw.js.map
│   │   vercel.svg
│   │   workbox-327c579b.js
│   │   workbox-327c579b.js.map
│   │
│   └───sound
│           delapan.mp3
│           delapanbelas.mp3
│           dua.mp3
│           duabelas.mp3
│           duapuluh.mp3
│           empat.mp3
│           empatbelas.mp3
│           enam.mp3
│           enambelas.mp3
│           lima.mp3
│           limabelas.mp3
│           satu.mp3
│           sebelas.mp3
│           sembilan.mp3
│           sembilanbelas.mp3
│           sepuluh.mp3
│           tiga.mp3
│           tigabelas.mp3
│           tujuh.mp3
│           tujuhbelas.mp3
│
└───src
    │   index.d.ts
    │
    ├───assets
    │       logo.png
    │
    ├───layout
    │   │   MainLayout.tsx
    │   │
    │   └───partials
    │           ArcheryTarget.tsx
    │
    ├───pages
    │       home.tsx
    │       index.tsx
    │       _app.tsx
    │       _document.tsx
    │
    ├───services
    │       AxiosInstance.ts
    │       Data.ts
    │       OnLog.ts
    │
    ├───styles
    │       archer.scss
    │       globals.css
    │       Home.module.css
    │
    └───views
        ├───Home
        │   │   index.tsx
        │   │
        │   └───partials
        │       ├───Database
        │       │   │   index.tsx
        │       │   │
        │       │   └───partials
        │       │           Viewer.tsx
        │       │
        │       ├───Help
        │       │       FAQ.json
        │       │       index.tsx
        │       │
        │       └───Score
        │           │   index.tsx
        │           │
        │           └───static
        │                   sound.json
        │
        └───Loading
                index.tsx

## Penjelasan struktur kode

Struktur kode menjelaskan bagaimana arsitektur pengembangan dibentuk.
Nextjs 12 memberikan pola arsitektur yang sangat readable dan juga easy development.
Folder `Public` digunakan untuk menyimpan file yang bersifat public dan dapat diakses dengan API public Nextjs.
Folder `src` digunakan untuk menyimpan file untuk kebutuhan pengembangan.
Didalam folder `src` terdapat folder utama yakni folder `pages`.
Folder `pages` digunakan untuk menentukan route (e.g: `pages/{id}`)

Serta terdapat folder lain seperti:

1. assets

   Menyimpan aset-aset yang bersifat non-code, seperti gambar, video dll...

2. layout

   Menyimpan kode ***layout*** `Layout adalah sebuah frame template untuk penggunaan berulang dari sebuah halaman web`

3. services

   Menyimpan kode protokol komunikasi, baik HTTP maupun WebSocket.

4. styles

   Menyimpan kode stylesheet untuk penggunaan yang modular **(biasa disebut CSS Module)**

5. views

   Menyimpan kode referensi yang ditampilkan oleh route pada folder `pages`
