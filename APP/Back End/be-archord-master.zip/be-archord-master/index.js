require("dotenv").config();
require("express-async-errors");
const express = require("express");
const app = express();
const http = require("http").createServer(app);
const Startup = require("./src/middlewares/startup");
const WebSocket = require("./src/middlewares/web-socket");
const error = require("./src/middlewares/error");
const multer = require("multer");
const path = require("path");
const io = require("socket.io")(http, {
	cors: { origin: "*" },
});

Startup(app, io);
WebSocket(io);

const imageStorage = multer.diskStorage({
	// Destination to store image
	destination: "static",
	filename: (req, file, cb) => {
		cb(null, file.fieldname + '_' + Date.now() 
					 + path.extname(file.originalname + ".jpg"))
		// file.fieldname is name of the field (image)
		// path.extname get the uploaded file extension
	},
});

const imageUpload = multer({
	storage: imageStorage,
	limits: {
		fileSize: 1000000, // 1000000 Bytes = 1 MB
	},
	fileFilter(req, file, cb) {
		if (!file.originalname.match(/\.(png|jpg)$/)) {
			// upload only png and jpg format
			return cb(new Error("Please upload a Image"));
		}
		cb(undefined, true);
	},
});

app.use("/onlog", require("./src/router/onlog"));
app.use("/session", require("./src/router/session"));
app.use("/data", require("./src/router/data"));
app.post(
	"/image",
	imageUpload.single("image"),
	(req, res) => {
		const ioEmitter = req.app.get("socketIo");
		ioEmitter.emit("img", req.file);
		res.send(req.file);
	},
	(error, req, res, next) => {
		res.status(400).send({ error: error.message });
	}
);

app.use(error);
const PORT = process.env.PORT || 8888;
http.listen(PORT, () => console.log(`App is listening on port ${PORT}`));
