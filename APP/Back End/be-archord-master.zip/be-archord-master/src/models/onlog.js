const mongoose = require("mongoose");

const OnlogSchema = new mongoose.Schema({
	absis: {
		type: Number,
		trim: true,
		required: true,
	},
	ordinat: {
		type: Number,
		trim: true,
		required: true,
	},
	score: {
		type: Number,
		trim: true,
		required: true,
	},
	lastUpdate: {
		type: Date,
		default: Date.now,
	},
});

const Onlog = mongoose.model("Onlog", OnlogSchema);

exports.Onlog = Onlog;
