const mongoose = require("mongoose");

const DataSchema = new mongoose.Schema({
	athlete: {
		type: String,
		trim: true,
		required: true,
	},
	data: {
		type: [Object],
		trim: true,
		required: true,
	},
	lastUpdate: {
		type: Date,
		default: Date.now,
	},
});

const Data = mongoose.model("Data", DataSchema);

exports.Data = Data;
