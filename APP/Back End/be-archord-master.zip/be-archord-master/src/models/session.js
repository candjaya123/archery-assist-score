const mongoose = require("mongoose");

const SessionSchema = new mongoose.Schema({
	data: {
		type: [Object],
		required: true,
	},
	lastUpdate: {
		type: Date,
		default: Date.now,
	},
});

const Session = mongoose.model("Session", SessionSchema);

exports.Session = Session;
