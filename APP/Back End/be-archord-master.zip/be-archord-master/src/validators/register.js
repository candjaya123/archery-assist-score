/*
  Memastikan masukan untuk registrasi device adalah benar
*/
