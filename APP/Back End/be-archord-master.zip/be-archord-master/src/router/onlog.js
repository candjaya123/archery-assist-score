const express = require("express");
const router = express.Router();
const { Onlog } = require("../models/onlog");
const { Session } = require("../models/session");

router.get("/", async (req, res) => {
	const dataResult = await Onlog.find();
	res.send(dataResult);
});

router.get("/last", async (req, res) => {
	const dataResult = await Onlog.find();
	res.send(dataResult[dataResult.length - 1]);
});

router.get("/save", async (req, res) => {
	const dataResult = await Onlog.find();

	const newSession = await new Session({
		data: dataResult,
	}).save();

	await Onlog.deleteMany({});

	return res.send(newSession);
});

router.post("/", async (req, res) => {
	const dataResult = await new Onlog({
		absis: req?.body?.absis || 0,
		ordinat: req?.body?.ordinat || 0,
		score: req?.body?.score || 0,
	}).save();

	const sessionResult = await Session.find();
	const onlogResult = await Onlog.find();

	const allData = [];

	if (sessionResult.length) {
		sessionResult.forEach((session, index) => {
			let sess = {};
			session?.data?.forEach((ses, i) => {
				sess = {
					...sess,
					[`shoot${i + 1}`]: ses?.score,
				};
			});

			allData.push(sess);
		});
	}

	if (onlogResult.length) {
		let onLogs = {};
		onlogResult.forEach((onlog, index) => {
			onLogs = {
				...onLogs,
				[`shoot${index + 1}`]: onlog?.score,
			};
		});

		onLogs = {
			...onLogs,
			[`shoot${onlogResult[onlogResult.length] + 1}`]: req?.body.score,
		};
		allData.push(onLogs);
	}

	const ioEmitter = req.app.get("socketIo");
	ioEmitter.emit("archord", {
		data: allData,
		lastData: req?.body?.score || 0,
	});

	return res.send(dataResult);
});

router.delete("/", async (req, res) => {
	const dataResult = await Onlog.deleteMany({});
	const sessionResult = await Session.find();
	const onlogResult = await Onlog.find();

	const allData = [];

	if (sessionResult.length) {
		sessionResult.forEach((session, index) => {
			let sess = {};
			session?.data?.forEach((ses, i) => {
				sess = {
					...sess,
					[`shoot${i + 1}`]: ses?.score,
				};
			});

			allData.push(sess);
		});
	}

	if (onlogResult.length) {
		let onLogs = {};
		onlogResult.forEach((onlog, index) => {
			onLogs = {
				...onLogs,
				[`shoot${index + 1}`]: onlog?.score,
			};
		});

		onLogs = {
			...onLogs,
			[`shoot${onlogResult[onlogResult.length] + 1}`]: req?.body.score,
		};
		allData.push(onLogs);
	}

	const ioEmitter = req.app.get("socketIo");
	ioEmitter.emit("archord", {
		data: allData,
		lastData: 0,
	});

	const onlogResultAfter = await Onlog.find();

	if(!onlogResultAfter.length){
		sessionResult[sessionResult.length - 1]?.data?.forEach( async e => {
			const __DataRes = await new Onlog({
				absis: e?.absis || 0,
				ordinat: e?.ordinat || 0,
				score: e?.score || 0,
			}).save();
		})
		const ____dataResult = await Session.findOneAndDelete({}, { sort: { _id: -1 } });
	}

	res.send(dataResult);
});

router.delete("/last", async (req, res) => {
	const dataResult = await Onlog.findOneAndDelete({}, { sort: { _id: -1 } });
	const sessionResult = await Session.find();
	const onlogResult = await Onlog.find();

	const allData = [];

	if (sessionResult.length) {
		sessionResult.forEach((session, index) => {
			let sess = {};
			session?.data?.forEach((ses, i) => {
				sess = {
					...sess,
					[`shoot${i + 1}`]: ses?.score,
				};
			});

			allData.push(sess);
		});
	}

	if (onlogResult.length) {
		let onLogs = {};
		onlogResult.forEach((onlog, index) => {
			onLogs = {
				...onLogs,
				[`shoot${index + 1}`]: onlog?.score,
			};
		});

		onLogs = {
			...onLogs,
			[`shoot${onlogResult[onlogResult.length] + 1}`]: req?.body.score,
		};
		allData.push(onLogs);
	}

	const ioEmitter = req.app.get("socketIo");
	ioEmitter.emit("archord", {
		data: allData,
		lastData: 0,
	});

	const onlogResultAfter = await Onlog.find();

	if(!onlogResultAfter.length){
		sessionResult[sessionResult.length - 1]?.data?.forEach( async e => {
			const __DataRes = await new Onlog({
				absis: e?.absis || 0,
				ordinat: e?.ordinat || 0,
				score: e?.score || 0,
			}).save();
		})
		const ____dataResult = await Session.findOneAndDelete({}, { sort: { _id: -1 } });
	}
	
	res.send(dataResult);
});

module.exports = router;
