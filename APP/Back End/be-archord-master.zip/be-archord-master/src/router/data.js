const express = require("express");
const { Data } = require("../models/data");
const { Onlog } = require("../models/onlog");
const router = express.Router();
const { Session } = require("../models/session");

router.get("/", async (req, res) => {
	const dataResult = await Data.find();
	res.send(dataResult);
});

router.get("/last", async (req, res) => {
	const dataResult = await Data.find();
	res.send(dataResult[dataResult.length - 1]);
});

router.get("/show", async (req, res) => {
	const sessionResult = await Session.find();
	const onlogResult = await Onlog.find();

	const allData = [];

	if (sessionResult.length) {
		sessionResult.forEach((session, index) => {
			let sess = {};
			session?.data?.forEach((ses, i) => {
				sess = {
					...sess,
					[`shoot${i + 1}`]: ses?.score,
				};
			});

			allData.push(sess);
		});
	}

	if (onlogResult.length) {
		let onLogs = {};
		onlogResult.forEach((onlog, index) => {
			onLogs = {
				...onLogs,
				[`shoot${index + 1}`]: onlog?.score,
			};
		});

		allData.push(onLogs);
	}

	res.send({data: allData});
});

router.delete("/", async (req, res) => {
	const dataResult = await Data.deleteMany({});
	res.send(dataResult);
});

router.delete("/:id", async (req, res) => {
	const dataResult = await Data.findByIdAndRemove(req?.params?.id);
	res.send(dataResult);
});

router.post("/save", async (req, res) => {
	const onlogResult = await Onlog.find();
	if (onlogResult.length) {
		const newSession = await new Session({
			data: onlogResult,
		}).save();

		await Onlog.deleteMany({});
	}

	const dataResult = await Session.find();

	const newData = await new Data({
		athlete: req?.body?.athlete,
		data: dataResult,
	}).save();

	await Session.deleteMany({});

	return res.send(newData);
});

module.exports = router;
