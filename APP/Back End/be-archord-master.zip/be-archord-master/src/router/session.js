const express = require("express");
const router = express.Router();
const { Onlog } = require("../models/onlog");
const { Session } = require("../models/session");

router.get("/", async (req, res) => {
	const dataResult = await Session.find();
	res.send(dataResult);
});

router.get("/last", async (req, res) => {
	const dataResult = await Session.find();
	res.send(dataResult[dataResult.length - 1]);
});

router.get("/save", async (req, res) => {
	const dataResult = await Session.find();

	const newSession = await new Session({
		data: dataResult
	}).save();

	await Onlog.deleteMany({})

	return res.send(newSession)
});

module.exports = router;
